import React, { Component, Fragment } from 'react'
import {Header,Footer} from './layouts/index'
import Exercise from './exercises/index'

export default class extends Component {
  render() {
    return  <Fragment >
  <Header />
  <Footer />

  </Fragment>
  }
}
